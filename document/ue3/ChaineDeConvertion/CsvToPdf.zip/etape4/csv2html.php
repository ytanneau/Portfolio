<!DOCTYPE html>
<html>
  <head>
    <title>Excel To HTML Using PHPSpreadSheet</title>
    <meta charset="utf-8">
  </head>
  <body>
    <table>
    <tr> 
    	<th>Classement</th>
    	<th>Nation</th>
    	<th>Or</th>
    	<th>Argent</th>
    	<th>Bronze</th>
    	<th>Total</th>
      <th>%</th>
    </tr>
    <?php
      $fichier = "TableauTrier.csv";
      $contenu = file($fichier);


      // (B2) OUTPUT HTML

      // CALCUL DU NOMBRE DE MÉDAILLES DANS LE TABLEAU (POUR LE POURCENTAGE)
      $totalMedaillesTableau = 0;
      foreach ($contenu as $ligne) { 
        $numElt = 0;
        $liste_ligne = explode(',', $ligne);
        foreach ($liste_ligne as $element) {
          if ($numElt >= 2) {
            $totalMedaillesTableau += $element;
          }
          $numElt += 1;
        }
      }

      # CRÉATION DU FICHIER HTML
      foreach ($contenu as $ligne) { 
        $numElt = 0;
        $totalMedailles = 0;
        $liste_ligne = explode(',', $ligne);
        echo "<tr>\n";
        foreach ($liste_ligne as $element) {
          echo "\t<td>";

          if ($numElt == 1) {
            echo "<img src=\"DrapFlat/";
            system("egrep $element < codeIsos.txt | cut -d, -f2 | tr [A-Z] [a-z] | head -1");
            echo ".webp\"> ";
          }
          if ($numElt >= 2) {
            $totalMedailles += $element;
          }
          
          echo $element ."</td>\n"; 
          $numElt += 1;
        }
        echo "\t<td>" . $totalMedailles . "</td>\n";
        echo "\t<td>" . (int)($totalMedailles / $totalMedaillesTableau * 10000) / 100 . "</td>\n";
        echo "</tr>\n";
      }
      system("rm temp");
    ?></table>
  </body>
</html>
