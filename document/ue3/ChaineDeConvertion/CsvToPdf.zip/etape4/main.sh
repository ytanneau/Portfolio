#!/bin/bash

#lancement du conteneur monté sur le volume créé
docker container run -dit --name html -v vconvert:/work sae103-html2pdf

chemin_volume=$(docker volume inspect vconvert --format '{{ .Mountpoint }}')


cp "./data/html.sh" "$chemin_volume"
cp ./data/*.php "$chemin_volume"

php csvtri.php
php csv2html.php

# conversion du fichier html en pdf
docker container exec html bash html.sh


#recuperation des fichiers convertis
mkdir -p ./output

cp -r "$chemin_volume" ./output

extensions=("png" "heic" "heif" "svg" "html" "gif" "csv" "xlsx" "sh" "php")

# Suppression des fichiers dans un autre format que les fichiers convertis

for ext in "${extensions[@]}"; do
    for fichier in ./output/*."$ext"; do
        # Vérifie si le fichier existe avant de tenter de le supprimer
        if [ -f "$fichier" ]; then
            echo "Suppression de $fichier"
            rm "$fichier"
        fi
    done
done

# Suppression des conteneurs une fois les conversions terminées
for conteneur in imagick html excel wget
do
        if docker ps -a --format '{{.Names}}' | grep -q "${conteneur}"
        then
                echo "Suppression du conteneur html..."
                docker container kill html
                docker rm -f html
        fi
done
