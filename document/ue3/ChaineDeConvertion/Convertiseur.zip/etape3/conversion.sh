#!/bin/bash

# Vérifie si le conteneur existe
for conteneur in imagick html excel wget
do
        if docker ps -a --format '{{.Names}}' | grep -q "${conteneur}"
        then
                echo "Suppression du conteneur ${conteneur}..."
                docker container kill "${conteneur}"
                docker rm -f "${conteneur}"
        fi
done

if docker volume ls | grep -q vconvert
then
	docker volume remove vconvert
	echo "suppression et récréation du volume vconvert..."
	docker volume create vconvert
else
	echo "création du volume vconvert"
	docker volume create vconvert
fi

#lancement des conteneurs montés sur le volume créé
docker container run -dit --name imagick -v vconvert:/data sae103-imagick
docker container run -dit --name html -v vconvert:/work sae103-html2pdf
docker container run -dit --name excel -v vconvert:/app sae103-excel2csv
docker container run -dit --name wget -v vconvert:/data sae103-wget

# copie des fichiers/execution des scripts

conteneurs=("imagick" "html" "excel" "wget")
convertis=("webp" "pdf" "csv")
extensions=("jpg" "png" "gif" "svg" "heif" "heic" "html" "xlsx" "csv" "txt")
chemin_volume=$(docker volume inspect vconvert --format '{{ .Mountpoint }}')


for script in "${conteneurs[@]}"; do
        cp "./data/$script.sh" "$chemin_volume"
done
cp ./data/*.php "$chemin_volume"

for ext in "${extensions[@]}"; do
	for fichier in *."$ext"; do
    		# Vérifie si le fichier existe
    	if [ -f "$fichier" ]; then
      		cp "./input/$fichier" "$chemin_volume"
    	fi
  	done
done

for nom_conteneur in "${conteneurs[@]}"; do
	# chaque script de conversion possède le même nom que le conteneur dans lequel il doit s'exécuter
	# Par exemple, le script qui convertit les images est appelé imagick, tout comme son conteneur
        docker container exec "$nom_conteneur" bash "$nom_conteneur.sh"
done

#exception pour les scripts php, qui génèrent un fichier csv
php csvtri.php
php csv2html.php

# conversion du fichier html en pdf
docker container exec html bash html.sh


#recuperation des fichiers convertis
mkdir -p ./output

cp -r "$chemin_volume" ./output

extensions=("png" "heic" "heif" "svg" "html" "gif" "csv" "xlsx" "sh" "php")

# Suppression des fichiers dans un autre format que les fichiers convertis

for ext in "${extensions[@]}"; do
    for fichier in ./output/*."$ext"; do
        # Vérifie si le fichier existe avant de tenter de le supprimer
        if [ -f "$fichier" ]; then
            echo "Suppression de $fichier"
            rm "$fichier"
        fi
    done
done

# Suppression des conteneurs une fois les conversions terminées
for conteneur in imagick html excel wget
do
        if docker ps -a --format '{{.Names}}' | grep -q "${conteneur}"
        then
                echo "Suppression du conteneur ${conteneur}..."
                docker container kill "${conteneur}"
                docker rm -f "${conteneur}"
        fi
done
