#!/bin/bash

# Variable pour vérifier si au moins un fichier a été traité
fichiers_traites=false
chemin_fichier=../input/
# Parcours des fichiers .xlsx dans le répertoire courant
for fichier in "$chemin_fichier"*.xlsx; do
  # Vérifie si le fichier existe
  if [ -f "$fichier" ]; then
    # Supprime l'extension pour obtenir le nom de base
    base="${fichier%.*}"
    ssconvert "$fichier" "$base.csv"
    fichiers_traites=true
  fi
done

# Message si aucun fichier n'a été traité
if [ "$fichiers_traites" = false ]; then
  echo "Aucun fichier .xlsx trouvé dans le répertoire courant."
fi

