#!/bin/bash
#variable contenant le chemin vers le dossier contenant le fichier codeIsos.txt
dossier_codes=$(pwd "$(readlink -f "$0")")

#Lecture des codes ISO par pays dans le fichier codeIsos.txt, 
#puis téléchargement des drapeaux correspondants aux formats "flat" et "waving"
for drap in $(cut -d, -f2 "$dossier_codes"/codeIsos.txt | tr [A-Z] [a-z] | tr -d '"'); do 
	wget https://flagcdn.com/h20/$drap.webp --directory-prefix=DrapFlat/
	wget https://flagcdn.com/80x60/$drap.webp --directory-prefix=DrapWaving/;
done
