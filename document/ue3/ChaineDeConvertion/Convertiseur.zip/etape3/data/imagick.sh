#!/bin/bash

dossier="."

# Extensions des fichiers à convertir
extensions=("jpg" "heif" "heic" "svg" "gif" "png")

# Boucle pour traiter chaque fichier avec une des extensions spécifiées
for ext in "${extensions[@]}"; do
    for fichier in "$dossier"/*.$ext; do
        # Vérification si le fichier avec l'extension existe
        if [ -f "$fichier" ]; then
            # Extraction du nom sans l'extension
            base="${fichier%.*}"
            
            # Conversion du fichier image en fichier webp
            convert "$fichier" "$base.webp"
            
            if [ $? -eq 0 ]; then
                echo "Conversion réussie : $base.webp"
            else
                echo "Erreur lors de la conversion de $fichier"
            fi
        fi
    done
done
