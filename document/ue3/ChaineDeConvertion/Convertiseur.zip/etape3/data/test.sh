#!/bin/bash

echo "Répertoire courant : $(pwd)"
echo "Fichiers disponibles :"
ls -l

if [[ -f ./codeIsos.txt ]]; then
    echo "Fichier codeIsos.txt trouvé."
else
    echo "Fichier codeIsos.txt introuvable."
    exit 1
fi

for drap in $(cut -d, -f2 ./codeIsos.txt | tr [A-Z] [a-z] | tr '"' ' '); do
    wget https://flagcdn.com/h20/$drap.webp --directory-prefix=DrapFlat/
    wget https://flagcdn.com/80x60/$drap.webp --directory-prefix=DrapWaving/
done

