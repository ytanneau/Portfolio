#!/bin/bash

# Variable pour vérifier si au moins un fichier a été traité
fichiers_traites=false
chemin_fichier=../input
# Parcours des fichiers .xlsx dans le répertoire courant
for fichier in "$chemin_fichier/*.html"; do
  # Vérifie si le fichier existe
  if [ -f "$fichier" ]; then
    # Supprime l'extension pour obtenir le nom de base
    base="${fichier%.*}"
    
    #Conversion du fichier
    weasyprint "$fichier" "$base.pdf"
    fichiers_traites=true
  fi
done

# Message si aucun fichier n'a été trouvé
if [ "$fichiers_traites" = false ]; then
  echo "Aucun fichier .html trouvé dans le répertoire courant."
fi
