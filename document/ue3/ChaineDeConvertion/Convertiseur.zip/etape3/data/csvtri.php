#!/usr/bin/php
<?php
    $fichierIn = 'Tableau.csv';
    $fichierOut = 'TableauTrier.csv';

    $ligne = file($fichierIn);
    $nbligne = count($ligne);

    $handle = fopen($fichierIn, 'r'); // Lire les en-têtes 
    $entetes = fgetcsv($handle); // Initialiser un tableau pour stocker les données 
    $donnees = []; // Lire le fichier ligne par ligne 

    while (($ligne = fgetcsv($handle)) !== FALSE) {
        $donnees[] = $ligne;
    } // Fermer le fichier fclose($handle); 

    fclose($handle); // Fonction de comparaison pour le tri (par exemple, par la première colonne)
    
    function comparerNom($a, $b) { 
        return strcmp($a[0], $b[0]);
    }

    function comparerBronze($a, $b) { 
        return ((int)$b[3] - (int)$a[3]);
    }

    function comparerArgent($a, $b) { 
        return ((int)$b[2] - (int)$a[2]);
    }

    function comparerOr($a, $b) { 
        return ((int)$b[1] - (int)$a[1]);
    }

    //print_r($donnees);

    unset($donnees[0]);
    unset($donnees[1]);

    //print_r($donnees);

    usort($donnees, 'comparerNom');
    usort($donnees, 'comparerBronze');
    usort($donnees, 'comparerArgent');
    usort($donnees, 'comparerOr');

    //usort($donnees, 'ajoutTotalMedaille');
    //usort($donnees, 'ajoutPosition');

    //echo implode(',', $entetes) . "\n";
    
    foreach ($donnees as $ligne) {
        $ligne[] = (int)$ligne[1]+(int)$ligne[2]+(int)$ligne[3];
    }
   
    array_unshift($donnees[0], 1);
    for ($i = 1; $i < count($donnees); $i++) {
        $ligne_actuelle = $donnees[$i];
        $ligne_precedente = $donnees[$i - 1]; // Comparaison des éléments (par exemple, comparer le premier élément de chaque ligne)
        
        if(($i != 0) &&
        ($ligne_actuelle[1]==$ligne_precedente[2])&&
        ($ligne_actuelle[2]==$ligne_precedente[3])&&
        ($ligne_actuelle[3]==$ligne_precedente[4])){
            array_unshift($donnees[$i], "-");
        }
        else{
            array_unshift($donnees[$i], $i+1);
        }
    }

    $handle = fopen($fichierOut, 'w'); // Parcourir chaque ligne de $donnees et l'écrire dans le fichier CSV
    foreach ($donnees as $ligne) {
        fputcsv($handle, $ligne);
    } // Fermer le fichier
    fclose($handle);


    //foreach ($donnees as $ligne) { 
    //    echo implode(',', $ligne) . "\n"; 
    //}

    //print_r($donnees);
?>
